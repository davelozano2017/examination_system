#
# TABLE STRUCTURE FOR: es_accounts_tbl
#

DROP TABLE IF EXISTS `es_accounts_tbl`;

CREATE TABLE `es_accounts_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('6', 'http://localhost/examination_system/assets/uploads/adminpicture1.png', 'Administrator', 'admin@noreply.com', 'Holy Spirit Quezon City', 'Male', '0', 'Administrator', '$2y$10$t6dhw0uuqAuzB3UCgAUZHuvvRQWSeZ1Tqbz5EnwhrADIib8cUw0am', '19th  April 2017 04:40:44 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('22', 'http://localhost/examination_system/assets/uploads/mahal.png', 'Jeddahlyn Cabuga', 'cabugajeddahlyn@gmail.com', 'Quezon City', 'Female', '1', 'ES-6569010', '$2y$10$H6e35/ftTpRLcaRwQHvEg.A4Nsa2IURVHWsBbtMDMJOKBMawY1aiq', 'April 21,  2017 03:45 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('23', 'http://localhost/examination_system/assets/uploads/sajer.jpg', 'Sajer Broncano', 'sajerbroncano@gmail.com', 'Bulacan City', 'Male', '1', 'ES-9370930', '$2y$10$aod4PqTmjc0yxWqL7xfxxeIZx660IQx18G2F1TiBEROqC.TRXrZeW', 'April 21,  2017 03:45 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('24', 'http://localhost/examination_system/assets/uploads/jade.png', 'Jade Batal', 'jadebatal@gmail.com', 'Caloocan City', 'Male', '1', 'ES-5752495', '$2y$10$QBymd9HS/RRa3MpFbtA4L.Ns94vs8PAhIl1k6dLcbNHQnVMZoe18y', 'April 21,  2017 03:45 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('25', 'http://localhost/examination_system/assets/uploads/paul.png', 'John Paul Bobila', 'johnpaulbobila@gmail.com', 'Caloocan City', 'Male', '1', 'ES-7315266', '$2y$10$VIpe5qobxmjFf4zAuKUW/uc8trm67AIqQGl3oAvVvXJ93I4ZJPMyS', 'April 21,  2017 03:45 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('26', 'http://localhost/examination_system/assets/uploads/shin.png', 'Shinjie Calica', 'shinjiecalica@gmail.com', 'Caloocan City', 'Male', '1', 'ES-5296223', '$2y$10$yoDx3/tD90ZE508Ee2eKeuqWed9T7WjsIyj74w/rtdowXLi5w2F1S', 'April 21,  2017 03:46 PM');
INSERT INTO `es_accounts_tbl` (`id`, `image`, `name`, `email`, `address`, `gender`, `role`, `username`, `password`, `date`) VALUES ('76', 'http://localhost/examination_system/assets/uploads/ako11.jpg', 'John David Lozano', 'lozanojohndavid@gmail.com', 'Quezon City', 'Male', '1', 'ES-6070953', '$2y$10$pLIdr2DDsHMPC8FTVvC3b.61t8J1A6kHxuOwmyqRndzpD6xfPH28i', 'June 8,  2017 04:50 PM');


#
# TABLE STRUCTURE FOR: es_category_tbl
#

DROP TABLE IF EXISTS `es_category_tbl`;

CREATE TABLE `es_category_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `es_category_tbl` (`id`, `category`) VALUES ('5', 'PC hardware and software');
INSERT INTO `es_category_tbl` (`id`, `category`) VALUES ('6', 'Logic Gates');
INSERT INTO `es_category_tbl` (`id`, `category`) VALUES ('7', 'PC Networking');


#
# TABLE STRUCTURE FOR: es_instructions_tbl
#

DROP TABLE IF EXISTS `es_instructions_tbl`;

CREATE TABLE `es_instructions_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructions` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `es_instructions_tbl` (`id`, `instructions`) VALUES ('5', 'The examination contains 20 questions.');
INSERT INTO `es_instructions_tbl` (`id`, `instructions`) VALUES ('7', 'Please choose your answer carefully.');
INSERT INTO `es_instructions_tbl` (`id`, `instructions`) VALUES ('8', '50% is the passing rate. Below that you have failed the exam.');
INSERT INTO `es_instructions_tbl` (`id`, `instructions`) VALUES ('13', 'If you are going to logout  your account when the assestment was started, then you will automatically fail your exam.');
INSERT INTO `es_instructions_tbl` (`id`, `instructions`) VALUES ('14', 'STRICTLY obey all instructions above.');


#
# TABLE STRUCTURE FOR: es_questions_tbl
#

DROP TABLE IF EXISTS `es_questions_tbl`;

CREATE TABLE `es_questions_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(1000) NOT NULL,
  `category` varchar(255) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  `option_a` varchar(1000) NOT NULL,
  `option_b` varchar(1000) NOT NULL,
  `option_c` varchar(1000) NOT NULL,
  `option_d` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('1', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('2', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('5', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('6', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('7', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('8', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('9', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('10', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('11', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('12', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('13', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('14', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('15', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('16', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('17', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('18', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('19', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('20', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('21', 'What is CPU?', 'PC hardware and software', 'Is a main brain of the computer.', 'Is a main brain of the computer.', 'N/a', 'N/a', 'N/a');
INSERT INTO `es_questions_tbl` (`id`, `question`, `category`, `answer`, `option_a`, `option_b`, `option_c`, `option_d`) VALUES ('22', 'RAM stands for?', 'PC hardware and software', 'Random Access Memory', 'Random Access Memory', 'Random Acces Memory', 'Random Access Memmory', 'Rand0m Access Memory');


#
# TABLE STRUCTURE FOR: es_results_tbl
#

DROP TABLE IF EXISTS `es_results_tbl`;

CREATE TABLE `es_results_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `score` int(11) NOT NULL,
  `percentage` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('1', 'Jeddahlyn Cabuga', 'cabugajeddahlyn@gmail.com', '20', '100', 'Passed', 'June 8,  2017 05:32 PM');
INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('2', 'John David Lozano', 'lozanojohndavid@gmail.com', '20', '100', 'Passed', 'June 8,  2017 05:33 PM');
INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('3', 'Sajer Broncano', 'sajerbroncano@gmail.com', '14', '85', 'Passed', 'June 8,  2017 05:33 PM');
INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('4', 'Jade Batal', 'jadebatal@gmail.com', '7', '67.5', 'Failed', 'June 8,  2017 05:33 PM');
INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('5', 'John Paul Bobila', 'johnpaulbobila@gmail.com', '20', '100', 'Passed', 'June 8,  2017 05:34 PM');
INSERT INTO `es_results_tbl` (`id`, `name`, `email`, `score`, `percentage`, `status`, `date`) VALUES ('6', 'Shinjie Calica', 'shinjiecalica@gmail.com', '9', '72.5', 'Failed', 'June 8,  2017 05:34 PM');


#
# TABLE STRUCTURE FOR: es_school_information
#

DROP TABLE IF EXISTS `es_school_information`;

CREATE TABLE `es_school_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `es_school_information` (`id`, `image`, `name`, `email`, `address`, `contact`) VALUES ('19', 'http://localhost/examination_system/assets/uploads/logo12111.png', 'Our Lady of Fatima University', 'examination@fatima.edu.ph', 'Lagro Hilltop Quezon City', '09226645555');


#
# TABLE STRUCTURE FOR: es_temp_tbl
#

DROP TABLE IF EXISTS `es_temp_tbl`;

CREATE TABLE `es_temp_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL,
  `code` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=801 DEFAULT CHARSET=latin1;

